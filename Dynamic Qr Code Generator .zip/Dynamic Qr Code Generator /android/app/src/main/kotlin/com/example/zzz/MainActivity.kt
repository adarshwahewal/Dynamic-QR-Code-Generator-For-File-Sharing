package com.example.zzz

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
